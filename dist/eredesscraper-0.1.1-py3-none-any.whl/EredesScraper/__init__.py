from EredesScraper.agent import EredesScraper
from EredesScraper.db_clients import InfluxDB
from EredesScraper.utils import parse_config
from EredesScraper.workflows import switchboard


